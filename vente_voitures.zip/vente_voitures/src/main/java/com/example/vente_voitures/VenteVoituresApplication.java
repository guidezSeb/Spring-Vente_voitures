package com.example.vente_voitures;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VenteVoituresApplication {

	public static void main(String[] args) {
		SpringApplication.run(VenteVoituresApplication.class, args);
	}

}
